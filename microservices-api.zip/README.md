# API REST com Microserviços - Node.js + Express + Sequelize

Sistema de controle de pedidos com arquitetura de microserviços.

## 📋 Pré-requisitos

- Node.js 18+ instalado
- MySQL Server instalado e rodando
- Git (opcional)

## 🗄️ Configuração do Banco de Dados

1. Conecte-se ao MySQL:
```bash
mysql -u root -p
```

2. Crie os bancos de dados:
```sql
CREATE DATABASE cliente_db;
CREATE DATABASE pedido_db;
```

3. Saia do MySQL:
```sql
exit;
```

## 🚀 Instalação e Execução

### 1. Cliente Service

```bash
cd cliente-service
npm install
```

Edite o arquivo `.env` com suas credenciais do MySQL:
```
DB_NAME=cliente_db
DB_USER=root
DB_PASS=SUA_SENHA_AQUI
DB_HOST=localhost
PORT=3001
```

Inicie o serviço:
```bash
npm start
```

O serviço estará rodando em: http://localhost:3001

### 2. Pedido Service

Abra um **novo terminal** e execute:

```bash
cd pedido-service
npm install
```

Edite o arquivo `.env` com suas credenciais do MySQL:
```
DB_NAME=pedido_db
DB_USER=root
DB_PASS=SUA_SENHA_AQUI
DB_HOST=localhost
CLIENTE_SERVICE_URL=http://localhost:3001/clientes
PORT=3002
```

Inicie o serviço:
```bash
npm start
```

O serviço estará rodando em: http://localhost:3002

## 📡 Endpoints da API

### Cliente Service (http://localhost:3001)

- **POST** `/clientes` - Criar cliente
- **GET** `/clientes` - Listar todos os clientes
- **GET** `/clientes/:id` - Buscar cliente por ID
- **PUT** `/clientes/:id` - Atualizar cliente
- **DELETE** `/clientes/:id` - Deletar cliente

### Pedido Service (http://localhost:3002)

- **POST** `/pedidos` - Criar pedido
- **GET** `/pedidos` - Listar todos os pedidos
- **GET** `/pedidos/:id` - Buscar pedido por ID
- **PUT** `/pedidos/:id` - Atualizar pedido
- **DELETE** `/pedidos/:id` - Deletar pedido

## 🧪 Testando a API

### 1. Criar um Cliente

```bash
curl -X POST http://localhost:3001/clientes   -H "Content-Type: application/json"   -d '{"nome": "João Silva", "email": "joao@email.com"}'
```

### 2. Listar Clientes

```bash
curl http://localhost:3001/clientes
```

### 3. Criar um Pedido

```bash
curl -X POST http://localhost:3002/pedidos   -H "Content-Type: application/json"   -d '{"descricao": "Notebook Dell", "valor": 3500.00, "clienteId": 1}'
```

### 4. Listar Pedidos

```bash
curl http://localhost:3002/pedidos
```

## 📝 Exemplos de Requisições

### Criar Cliente
```json
POST /clientes
{
  "nome": "Maria Santos",
  "email": "maria@email.com"
}
```

### Atualizar Cliente
```json
PUT /clientes/1
{
  "nome": "Maria Santos Silva",
  "email": "maria.santos@email.com"
}
```

### Criar Pedido
```json
POST /pedidos
{
  "descricao": "Mouse Gamer",
  "valor": 150.00,
  "clienteId": 1
}
```

### Atualizar Pedido
```json
PUT /pedidos/1
{
  "descricao": "Mouse Gamer RGB",
  "valor": 180.00,
  "clienteId": 1
}
```

## 🏗️ Arquitetura

O projeto utiliza arquitetura de microserviços:

- **Cliente Service**: Gerencia o cadastro de clientes
- **Pedido Service**: Gerencia pedidos e valida clientes via HTTP

Cada serviço possui:
- Banco de dados independente
- API REST própria
- Comunicação síncrona via HTTP

## 🔧 Tecnologias Utilizadas

- **Node.js**: Runtime JavaScript
- **Express**: Framework web
- **Sequelize**: ORM para MySQL
- **MySQL**: Banco de dados relacional
- **dotenv**: Gerenciamento de variáveis de ambiente

## ⚠️ Observações

- Certifique-se de que o **Cliente Service** está rodando antes de iniciar o **Pedido Service**
- Os dois serviços devem rodar em terminais separados
- Atualize as senhas do MySQL nos arquivos `.env` de cada serviço
- O Pedido Service valida a existência do cliente antes de criar/atualizar pedidos

## 📦 Estrutura do Projeto

```
microservices-api/
├── cliente-service/
│   ├── config/
│   │   └── database.js
│   ├── controllers/
│   │   └── clienteController.js
│   ├── models/
│   │   └── Cliente.js
│   ├── routes/
│   │   └── clienteRoutes.js
│   ├── .env
│   ├── .env.example
│   ├── index.js
│   └── package.json
│
├── pedido-service/
│   ├── config/
│   │   └── database.js
│   ├── controllers/
│   │   └── pedidoController.js
│   ├── models/
│   │   └── Pedido.js
│   ├── routes/
│   │   └── pedidoRoutes.js
│   ├── .env
│   ├── .env.example
│   ├── index.js
│   └── package.json
│
└── README.md
```

## 🐛 Troubleshooting

**Erro de conexão com o banco:**
- Verifique se o MySQL está rodando
- Confirme as credenciais no arquivo `.env`
- Certifique-se de que os bancos de dados foram criados

**Erro ao criar pedido:**
- Verifique se o Cliente Service está rodando
- Confirme que o clienteId existe no banco de clientes

**Porta já em uso:**
- Altere a porta no arquivo `.env` do serviço correspondente
